
document.addEventListener('deviceready', function () {
  var db = window.sqlitePlugin.openDatabase({ name: 'meuapp.db', location: 'default' });

  db.transaction(function (tx) {
    tx.executeSql('CREATE TABLE IF NOT EXISTS itens (id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT, categoria TEXT, descricao TEXT, favorito INTEGER)');
  });

  // Salvar item
  window.salvarItem = function(url, categoria, descricao, favorito) {
    db.transaction(function (tx) {
      tx.executeSql('INSERT INTO itens (url, categoria, descricao, favorito) VALUES (?, ?, ?, ?)', 
        [url, categoria, descricao, favorito ? 1 : 0],
        function(tx, res) {
          alert("Item salvo com sucesso!");
        },
        function(error) {
          alert("Erro ao salvar item: " + error.message);
        });
    });
  }

  // Listar itens
  window.listarItens = function(callback) {
    db.transaction(function (tx) {
      tx.executeSql('SELECT * FROM itens', [], function (tx, res) {
        let resultados = [];
        for (let i = 0; i < res.rows.length; i++) {
          resultados.push(res.rows.item(i));
        }
        if (callback) callback(resultados);
      });
    });
  }
});
